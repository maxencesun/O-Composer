import { findById } from "./event-model.js?v=20260701-3";

export function getControl(eventModel, id) {
  return findById(eventModel.controls, id);
}

export function getCourse(eventModel, id) {
  return findById(eventModel.courses, id);
}

export function getCourseControl(eventModel, id) {
  return findById(eventModel.courseControls, id);
}

export function sortedCourses(eventModel, includeHidden = true) {
  return [...eventModel.courses]
    .filter(course => includeHidden || !course.options?.hideFromReports)
    .sort((a, b) => (a.order || 0) - (b.order || 0) || a.name.localeCompare(b.name));
}

export function enumerateCourseControlIds(eventModel, courseId, options = {}) {
  const course = getCourse(eventModel, courseId);
  if (!course || !course.firstCourseControl) {
    return [];
  }

  const result = [];
  const seen = new Set();
  const allBranches = !!options.allBranches;
  const variationChoices = Array.isArray(options.variationChoices)
    ? options.variationChoices.map(Number).filter(Boolean)
    : [];
  const maxSteps = Math.max(1000, eventModel.courseControls.length * 20);
  let steps = 0;

  function visit(id, joinId = null, ignoreFirstSplit = false, sharedSplitControlId = null) {
    let currentId = id;
    let first = true;
    while (currentId && currentId !== joinId && steps++ < maxSteps) {
      const courseControl = getCourseControl(eventModel, currentId);
      if (!courseControl) {
        break;
      }
      const skipSharedSplitStart = first
        && ignoreFirstSplit
        && sharedSplitControlId
        && Number(courseControl.control) === Number(sharedSplitControlId);

      const split = !!courseControl.variation;
      if (split && !(first && ignoreFirstSplit) && courseControl.variationCourseControls.length) {
        if (!seen.has(currentId) || allBranches) {
          result.push(currentId);
          seen.add(currentId);
        }
        const branches = courseControl.variationCourseControls;
        if (allBranches) {
          for (const branchId of branches) {
            visit(branchId, courseControl.variationEnd, true, courseControl.control);
          }
          currentId = courseControl.variation === "loop" ? courseControl.nextCourseControl : courseControl.variationEnd;
          first = false;
          continue;
        }

        if (variationChoices.length) {
          if (courseControl.variation === "loop") {
            const loopBranches = variationChoices.filter(choice => branches.includes(choice));
            for (const branchId of loopBranches) {
              visit(branchId, courseControl.variationEnd, true, courseControl.control);
              // In a Purple Pen loop the runner returns to the loop owner after
              // every loop.  Keep that repeated checkpoint in a chosen variation
              // sequence; otherwise the map line jumps from one loop directly to
              // the next and the loop is no longer a loop.
              result.push(currentId);
            }
            currentId = courseControl.nextCourseControl;
            first = false;
            continue;
          }
          const selectedBranch = variationChoices.find(choice => branches.includes(choice)) || branches[0];
          if (selectedBranch) {
            visit(selectedBranch, courseControl.variationEnd, true, courseControl.control);
            currentId = courseControl.variationEnd;
            first = false;
            continue;
          }
        }

        const defaultBranch = branches[0] || currentId;
        if (defaultBranch !== currentId) {
          visit(defaultBranch, courseControl.variationEnd, true, courseControl.control);
          if (courseControl.variation === "loop") {
            result.push(currentId);
          }
          currentId = courseControl.variation === "loop" ? courseControl.nextCourseControl : courseControl.variationEnd;
          first = false;
          continue;
        }
      }

      if (!skipSharedSplitStart && (!seen.has(currentId) || allBranches)) {
        result.push(currentId);
        seen.add(currentId);
      }
      currentId = courseControl.nextCourseControl;
      first = false;
    }
  }

  visit(course.firstCourseControl);
  return result;
}

export function courseView(eventModel, courseId, options = {}) {
  if (courseId === "all") {
    return allControlsView(eventModel);
  }

  const course = getCourse(eventModel, courseId);
  if (!course) {
    return [];
  }

  let ordinal = course.firstControlOrdinal || 1;
  const allBranchOrdinals = options.allBranches
    ? allBranchOrdinalMap(eventModel, course)
    : null;
  return enumerateCourseControlIds(eventModel, courseId, options)
    .map(courseControlId => {
      const courseControl = getCourseControl(eventModel, courseControlId);
      const control = getControl(eventModel, courseControl?.control);
      if (!courseControl || !control) {
        return null;
      }
      const mandatoryNormal = control.kind === "normal" && !isTeamFreeCourseControl(course, courseControl);
      const displayOrdinal = mandatoryNormal
        ? (allBranchOrdinals?.get(Number(courseControl.id)) || ordinal++)
        : "";
      return {
        course,
        courseControl,
        control,
        ordinal: displayOrdinal,
        teamRole: teamCourseControlRole(course, courseControl),
        label: labelForControl(course, courseControl, control, displayOrdinal)
      };
    })
    .filter(Boolean);
}

export function courseTopology(eventModel, courseId) {
  const course = getCourse(eventModel, courseId);
  if (!course || course.kind === "score") {
    return [];
  }

  const views = [];
  const viewByCourseControlId = new Map();
  const handledSplitOwners = new Set();
  const maxSteps = Math.max(1000, eventModel.courseControls.length * 20);
  let steps = 0;

  function branchIsHiddenMarker(ownerCourseControl, branchCourseControl) {
    if (!branchCourseControl || !ownerCourseControl) return false;
    return Number(branchCourseControl.id) === Number(ownerCourseControl.id)
      || Number(branchCourseControl.control) === Number(ownerCourseControl.control);
  }

  function branchDisplayStart(ownerCourseControl, branchCourseControl, joinCourseControlId) {
    if (!branchCourseControl) return Number(joinCourseControlId) || 0;
    // New relay branches use a hidden marker with the same map control as the
    // fork owner; imported Purple Pen files may use the first real branch
    // control directly. Handle both formats.
    if (branchIsHiddenMarker(ownerCourseControl, branchCourseControl)) {
      return Number(branchCourseControl.nextCourseControl) || Number(joinCourseControlId) || 0;
    }
    return Number(branchCourseControl.id) || Number(joinCourseControlId) || 0;
  }

  function addView(courseControl) {
    const control = getControl(eventModel, courseControl?.control);
    if (!courseControl || !control) return null;

    if (courseControl.variation && courseControl.variationCourseControls?.length) {
      const ownerId = Number(courseControl.id);
      if (handledSplitOwners.has(ownerId)) {
        return viewByCourseControlId.get(ownerId) ?? null;
      }

      const realBranchCourseControlIds = (courseControl.variationCourseControls || [])
        .map(Number)
        .filter(Boolean);
      const realBranchCourseControls = realBranchCourseControlIds
        .map(id => getCourseControl(eventModel, id))
        .filter(Boolean);
      const joinCourseControlId = Number(courseControl.variationEnd) || null;
      const loop = courseControl.variation === "loop";
      const loopExitCourseControlId = loop ? Number(courseControl.nextCourseControl) || null : null;
      const branchStartIds = realBranchCourseControls
        .map(branch => branchDisplayStart(courseControl, branch, joinCourseControlId))
        .filter(Boolean);

      // Purple Pen's loop is not a fork followed by a synthetic join. The split
      // control is also the join control: leg 0 is the fall-through edge that
      // leaves the loop, while legs 1..N are the loops that return to this same
      // control. Keep the arrays aligned with legTo so the fall-through edge has
      // no branch id and loop branch labels start at index 1.
      const branchCourseControlIds = loop ? [null, ...realBranchCourseControlIds] : realBranchCourseControlIds;
      const branchCourseControls = loop ? [null, ...realBranchCourseControls] : realBranchCourseControls;
      const legToCourseControlIds = loop
        ? [loopExitCourseControlId, ...branchStartIds].filter(Boolean)
        : branchStartIds;

      const view = {
        course,
        control,
        // The visible node is the fork/loop owner. Branch starts are hidden
        // course-control markers used only to keep each relay branch stable.
        courseControlIds: [ownerId],
        courseControls: [courseControl],
        ownerCourseControlId: ownerId,
        branchCourseControlIds,
        branchCourseControls,
        variation: courseControl.variation,
        joinCourseControlId,
        loopExitCourseControlId,
        legToCourseControlIds,
        legTo: [],
        joinIndex: -1
      };

      const index = views.length;
      views.push(view);
      handledSplitOwners.add(ownerId);
      viewByCourseControlId.set(ownerId, index);
      for (const branch of realBranchCourseControls) {
        if (branchIsHiddenMarker(courseControl, branch)) {
          viewByCourseControlId.set(Number(branch.id), index);
        }
      }


      return index;
    }

    if (viewByCourseControlId.has(Number(courseControl.id))) {
      return viewByCourseControlId.get(Number(courseControl.id));
    }
    const view = {
      course,
      control,
      courseControlIds: [Number(courseControl.id)],
      courseControls: [courseControl],
      ownerCourseControlId: Number(courseControl.id),
      branchCourseControlIds: [],
      branchCourseControls: [],
      variation: "",
      joinCourseControlId: null,
      legToCourseControlIds: Number(courseControl.nextCourseControl) ? [Number(courseControl.nextCourseControl)] : [],
      legTo: [],
      joinIndex: -1
    };
    const index = views.length;
    views.push(view);
    viewByCourseControlId.set(Number(courseControl.id), index);
    return index;
  }

  function visit(startId, joinId = null) {
    let currentId = Number(startId) || 0;
    while (currentId && currentId !== Number(joinId) && steps++ < maxSteps) {
      const courseControl = getCourseControl(eventModel, currentId);
      if (!courseControl) break;
      const index = addView(courseControl);
      if (index == null) break;
      const view = views[index];
      if (courseControl.variation && courseControl.variationCourseControls?.length) {
        const isLoop = courseControl.variation === "loop";
        for (const branchId of courseControl.variationCourseControls || []) {
          const branch = getCourseControl(eventModel, branchId);
          visit(branchDisplayStart(courseControl, branch, courseControl.variationEnd), courseControl.variationEnd);
        }
        currentId = Number(isLoop ? courseControl.nextCourseControl : courseControl.variationEnd) || 0;
      }
      else {
        currentId = Number(courseControl.nextCourseControl) || 0;
      }
    }
  }

  visit(course.firstCourseControl);

  function resolveTopologyTarget(id) {
    const targetId = Number(id) || 0;
    if (!targetId) return undefined;
    return viewByCourseControlId.get(targetId);
  }

  for (const view of views) {
    view.legTo = view.legToCourseControlIds
      .map(id => resolveTopologyTarget(id))
      .filter(index => Number.isInteger(index));
    view.joinIndex = view.variation === "loop"
      ? views.indexOf(view)
      : (view.joinCourseControlId ? viewByCourseControlId.get(Number(view.joinCourseControlId)) ?? -1 : -1);
  }

  return views;
}

export function courseGraphCourseControlIds(eventModel, courseId) {
  const course = getCourse(eventModel, courseId);
  if (!course) return [];
  const ids = [];
  const seen = new Set();
  const maxSteps = Math.max(1000, eventModel.courseControls.length * 20);
  let steps = 0;

  function visit(startId, joinId = null) {
    let currentId = Number(startId) || 0;
    while (currentId && currentId !== Number(joinId) && steps++ < maxSteps) {
      if (seen.has(currentId)) break;
      const courseControl = getCourseControl(eventModel, currentId);
      if (!courseControl) break;
      seen.add(currentId);
      ids.push(currentId);

      if (courseControl.variation && courseControl.variationCourseControls?.length) {
        for (const branchId of courseControl.variationCourseControls || []) {
          visit(branchId, courseControl.variationEnd);
        }
        currentId = Number(courseControl.variation === "loop" ? courseControl.nextCourseControl : courseControl.variationEnd) || 0;
      }
      else {
        currentId = Number(courseControl.nextCourseControl) || 0;
      }
    }
  }

  visit(course.firstCourseControl);
  return ids;
}

export function allControlsView(eventModel) {
  return [...eventModel.controls]
    .sort(compareControls)
    .map(control => ({
      course: null,
      courseControl: null,
      control,
      ordinal: "",
      label: control.code || controlKindLabel(control.kind)
    }));
}

export function courseLegs(eventModel, courseId, options = {}) {
  const course = getCourse(eventModel, courseId);
  if (!course) {
    return [];
  }

  const view = courseView(eventModel, courseId, options);
  if (course.kind === "score") {
    return scoreCourseFinishLeg(eventModel, course, view);
  }
  if (course.kind === "team") {
    return teamCourseLegs(eventModel, course, view);
  }
  if (options.allBranches) {
    return topologyCourseLegs(eventModel, courseId);
  }
  const legs = [];
  for (let i = 0; i < view.length - 1; i += 1) {
    const from = view[i];
    const to = view[i + 1];
    if (!from.control || !to.control) {
      continue;
    }
    if (from.courseControl?.mapExchange && options.partOnly) {
      continue;
    }
    legs.push({
      from,
      to,
      leg: findLeg(eventModel, from.control.id, to.control.id),
      length: legLength(eventModel, from.control.id, to.control.id)
    });
  }
  return legs;
}

function topologyCourseLegs(eventModel, courseId) {
  const topology = courseTopology(eventModel, courseId);
  const legs = [];
  for (const view of topology) {
    for (let index = 0; index < view.legTo.length; index += 1) {
      const toView = topology[view.legTo[index]];
      const fromCourseControl = view.branchCourseControls?.[index] || view.courseControls[index] || view.courseControls[0];
      const toCourseControl = toView?.courseControls[0];
      if (!fromCourseControl || !toCourseControl || !view.control || !toView?.control) continue;
      const from = rowForCourseControl(eventModel, view.course, fromCourseControl, view.control);
      const to = rowForCourseControl(eventModel, toView.course, toCourseControl, toView.control);
      legs.push({
        from,
        to,
        leg: findLeg(eventModel, view.control.id, toView.control.id),
        length: legLength(eventModel, view.control.id, toView.control.id)
      });
    }
  }
  return legs;
}

function rowForCourseControl(eventModel, course, courseControl, control) {
  return {
    course,
    courseControl,
    control,
    ordinal: "",
    label: labelForControl(course, courseControl, control, "")
  };
}

function scoreCourseFinishLeg(eventModel, course, view) {
  const legs = [];
  const mapIssue = view.find(row => row.control?.kind === "map-issue");
  const start = view.find(row => row.control?.kind === "start");
  if (mapIssue && start) {
    legs.push({
      from: mapIssue,
      to: start,
      leg: findLeg(eventModel, mapIssue.control.id, start.control.id),
      length: legLength(eventModel, mapIssue.control.id, start.control.id)
    });
  }
  const startControlId = Number(course.options?.scoreFinishControl) || 0;
  if (!startControlId) {
    return legs;
  }
  const from = view.find(row => Number(row.control?.id) === startControlId && row.control?.kind === "normal");
  const to = view.find(row => row.control?.kind === "finish");
  if (!from || !to) {
    return legs;
  }
  legs.push({
    from,
    to,
    leg: findLeg(eventModel, from.control.id, to.control.id),
    length: legLength(eventModel, from.control.id, to.control.id)
  });
  return legs;
}
function teamCourseLegs(eventModel, course, view) {
  const legs = [];
  const mandatoryRows = view.filter(row => row.control?.kind !== "normal" || !isTeamFreeCourseControl(course, row.courseControl));
  for (let i = 0; i < mandatoryRows.length - 1; i += 1) {
    const from = mandatoryRows[i];
    const to = mandatoryRows[i + 1];
    if (!from.control || !to.control) continue;
    if (from.courseControl?.mapExchange) continue;
    legs.push({
      from,
      to,
      leg: findLeg(eventModel, from.control.id, to.control.id),
      length: legLength(eventModel, from.control.id, to.control.id)
    });
  }
  return legs;
}


export function findLeg(eventModel, startControlId, endControlId) {
  return eventModel.legs.find(leg =>
    Number(leg.startControl) === Number(startControlId) &&
    Number(leg.endControl) === Number(endControlId)
  ) || null;
}

export function legPath(eventModel, startControlId, endControlId) {
  const start = getControl(eventModel, startControlId);
  const end = getControl(eventModel, endControlId);
  if (!start || !end) {
    return [];
  }
  const leg = findLeg(eventModel, startControlId, endControlId);
  return [start.location, ...(leg?.bends || []), end.location];
}

export function legLength(eventModel, startControlId, endControlId) {
  const start = getControl(eventModel, startControlId);
  const end = getControl(eventModel, endControlId);
  if (!start || !end) {
    return 0;
  }

  const leg = findLeg(eventModel, startControlId, endControlId);
  const flagging = normalizeFlaggingKind(leg?.flagging?.kind);

  // No mandatory route or entire leg mandatory — use path distance for "all",
  // straight-line for "none"
  if (flagging === "none") {
    return distance(start.location, end.location);
  }
  if (flagging === "all") {
    const path = legPath(eventModel, startControlId, endControlId);
    return pathLength(path);
  }

  // Partial mandatory route:
  // - Unmarked segments: straight-line distance between endpoints
  // - Mandatory (flagged) segment: distance along the purple line (path)
  const path = legPath(eventModel, startControlId, endControlId);
  const total = pathLength(path);
  if (total <= 0) {
    return distance(start.location, end.location);
  }

  // Determine flag start/end distances along the path
  let flagStart = 0;
  let flagEnd = total;

  if (flagging === "begin") {
    flagStart = 0;
    flagEnd = clamp(Number(leg.flagging?.end) || total / 2, 0, total);
  } else if (flagging === "end") {
    flagStart = clamp(Number(leg.flagging?.start) || total / 2, 0, total);
    flagEnd = total;
  } else if (flagging === "middle") {
    flagStart = clamp(Number(leg.flagging?.start) || total * 0.35, 0, total);
    flagEnd = clamp(Number(leg.flagging?.end) || total * 0.65, flagStart, total);
  }

  const flagStartPoint = pointAtPathDistance(path, flagStart);
  const flagEndPoint = pointAtPathDistance(path, flagEnd);

  // Unmarked before flag: start → flag start (straight line)
  // Mandatory segment: flag start → flag end (along purple line path)
  // Unmarked after flag: flag end → end (straight line)
  let length = 0;
  length += distance(start.location, flagStartPoint);
  length += pathSegmentLength(path, flagStart, flagEnd);
  length += distance(flagEndPoint, end.location);
  return length;
}

function normalizeFlaggingKind(kind) {
  return { "beginning-part": "begin", "end-part": "end", "middle-part": "middle" }[kind] || kind || "none";
}

function clamp(value, min, max) {
  return Math.max(min, Math.min(max, value));
}

function pathLength(points) {
  let length = 0;
  for (let i = 0; i < points.length - 1; i += 1) {
    length += distance(points[i], points[i + 1]);
  }
  return length;
}

function pathSegmentLength(points, startDist, endDist) {
  let length = 0;
  let offset = 0;
  for (let i = 0; i < points.length - 1; i += 1) {
    const segLen = distance(points[i], points[i + 1]);
    const segStart = offset;
    const segEnd = offset + segLen;
    // Overlap of [startDist, endDist] with [segStart, segEnd]
    const overlapStart = Math.max(startDist, segStart);
    const overlapEnd = Math.min(endDist, segEnd);
    if (overlapStart < overlapEnd) {
      length += overlapEnd - overlapStart;
    }
    offset = segEnd;
  }
  return length;
}

function pointAtPathDistance(points, target) {
  let remaining = clamp(target, 0, pathLength(points));
  for (let i = 0; i < points.length - 1; i += 1) {
    const a = points[i];
    const b = points[i + 1];
    const length = distance(a, b);
    if (remaining <= length && length > 0) {
      const t = remaining / length;
      return { x: a.x + (b.x - a.x) * t, y: a.y + (b.y - a.y) * t };
    }
    remaining -= length;
  }
  return { ...points[points.length - 1] };
}

export function courseLength(eventModel, courseId, options = {}) {
  const course = getCourse(eventModel, courseId);
  if (!course) {
    return 0;
  }
  if (!options.variationChoices?.length && !options.allBranches && course.options?.courseLength) {
    return course.options.courseLength;
  }
  return courseLegs(eventModel, courseId, options).reduce((sum, leg) => sum + leg.length, 0);
}

export function controlsUsedByCourse(eventModel, courseId) {
  return new Set(courseView(eventModel, courseId, { allBranches: true }).map(row => row.control.id));
}

export function coursesUsingControl(eventModel, controlId) {
  return sortedCourses(eventModel)
    .filter(course => controlsUsedByCourse(eventModel, course.id).has(Number(controlId)));
}

export function eventBounds(eventModel) {
  const points = [];
  for (const control of eventModel.controls) {
    points.push(control.location);
  }
  for (const special of eventModel.specials) {
    points.push(...(special.locations || []));
  }

  if (eventModel.event.printArea && !eventModel.event.printArea.automatic) {
    const area = eventModel.event.printArea;
    points.push({ x: area.left, y: area.top }, { x: area.right, y: area.bottom });
  }
  for (const course of eventModel.courses || []) {
    if (course.printArea && !course.printArea.automatic) {
      points.push({ x: course.printArea.left, y: course.printArea.top }, { x: course.printArea.right, y: course.printArea.bottom });
    }
    for (const partArea of course.partPrintAreas || []) {
      if (partArea.area && !partArea.area.automatic) {
        points.push({ x: partArea.area.left, y: partArea.area.top }, { x: partArea.area.right, y: partArea.area.bottom });
      }
    }
  }

  if (!points.length) {
    return { left: -100, right: 100, top: 100, bottom: -100, width: 200, height: 200 };
  }

  let left = Infinity;
  let right = -Infinity;
  let top = -Infinity;
  let bottom = Infinity;
  for (const point of points) {
    left = Math.min(left, point.x);
    right = Math.max(right, point.x);
    top = Math.max(top, point.y);
    bottom = Math.min(bottom, point.y);
  }

  const padding = Math.max(20, Math.max(right - left, top - bottom) * 0.12);
  left -= padding;
  right += padding;
  top += padding;
  bottom -= padding;
  return {
    left,
    right,
    top,
    bottom,
    width: Math.max(1, right - left),
    height: Math.max(1, top - bottom)
  };
}

export function createCourseSummary(eventModel) {
  const rows = sortedCourses(eventModel).map(course => {
    const view = courseView(eventModel, course.id);
    const controls = view.filter(row => row.control.kind === "normal").length;
    const freeControls = course.kind === "team" ? view.filter(row => row.control.kind === "normal" && isTeamFreeCourseControl(course, row.courseControl)).length : 0;
    return {
      course: course.name,
      kind: course.kind,
      controls,
      freeControls,
      length: courseLength(eventModel, course.id),
      climb: course.options?.climb ?? -1,
      load: course.options?.load ?? -1,
      hidden: !!course.options?.hideFromReports
    };
  });
  return rows;
}

export function createEventAudit(eventModel) {
  const issues = [];
  const codes = new Map();
  for (const control of eventModel.controls) {
    if (control.kind === "normal") {
      if (!control.code) {
        issues.push({ severity: "warning", item: `Control ${control.id}`, message: "Normal control has no code." });
      }
      if (codes.has(control.code)) {
        issues.push({ severity: "error", item: `Control ${control.id}`, message: `Code ${control.code} is used more than once.` });
      }
      codes.set(control.code, control.id);
    }
  }

  for (const course of sortedCourses(eventModel)) {
    const view = courseView(eventModel, course.id);
    if (!view.some(row => row.control.kind === "start")) {
      issues.push({ severity: "warning", item: course.name, message: "Course has no start control." });
    }
    if (!view.some(row => row.control.kind === "finish")) {
      issues.push({ severity: "warning", item: course.name, message: "Course has no finish control." });
    }
    for (const row of view) {
      if (!row.control) {
        issues.push({ severity: "error", item: course.name, message: `Missing control for course-control ${row.courseControl?.id}.` });
      }
    }
  }

  const usedControls = new Set();
  for (const course of sortedCourses(eventModel)) {
    for (const id of controlsUsedByCourse(eventModel, course.id)) {
      usedControls.add(id);
    }
  }
  for (const control of eventModel.controls) {
    if (!usedControls.has(control.id)) {
      issues.push({ severity: "info", item: `Control ${control.code || control.id}`, message: "Control is not used by any course." });
    }
  }

  return issues;
}

export function createLegLengthRows(eventModel) {
  const rows = [];
  for (const course of sortedCourses(eventModel)) {
    for (const leg of courseLegs(eventModel, course.id)) {
      rows.push({
        course: course.name,
        from: leg.from.control.code || controlKindLabel(leg.from.control.kind),
        to: leg.to.control.code || controlKindLabel(leg.to.control.kind),
        length: leg.length
      });
    }
  }
  return rows;
}

export function createControlCrossref(eventModel) {
  return [...eventModel.controls].sort(compareControls).map(control => ({
    id: control.id,
    code: control.code || controlKindLabel(control.kind),
    kind: control.kind,
    courses: coursesUsingControl(eventModel, control.id).map(course => course.name)
  }));
}

export function createLoadReport(eventModel) {
  const controls = createControlCrossref(eventModel).map(row => ({
    ...row,
    load: row.courses.reduce((sum, courseName) => {
      const course = eventModel.courses.find(candidate => candidate.name === courseName);
      const load = course?.options?.load ?? -1;
      return sum + (load > 0 ? load : 0);
    }, 0)
  }));

  const legMap = new Map();
  for (const course of sortedCourses(eventModel)) {
    const load = course.options?.load > 0 ? course.options.load : 0;
    for (const leg of courseLegs(eventModel, course.id)) {
      const key = `${leg.from.control.id}-${leg.to.control.id}`;
      const reverseKey = `${leg.to.control.id}-${leg.from.control.id}`;
      const existing = legMap.get(key) || legMap.get(reverseKey) || {
        from: leg.from.control.code || controlKindLabel(leg.from.control.kind),
        to: leg.to.control.code || controlKindLabel(leg.to.control.kind),
        courses: [],
        load: 0
      };
      existing.courses.push(course.name);
      existing.load += load;
      legMap.set(key, existing);
    }
  }

  return {
    controls,
    legs: [...legMap.values()]
  };
}

export function controlKindLabel(kind) {
  switch (kind) {
    case "start": return "Start";
    case "finish": return "Finish";
    case "crossing-point": return "Crossing";
    case "map-issue": return "Map issue";
    case "map-exchange": return "Map exchange";
    default: return "Control";
  }
}

export function compareControls(a, b) {
  const order = {
    "map-issue": 0,
    start: 1,
    "map-exchange": 2,
    normal: 3,
    finish: 4,
    "crossing-point": 5
  };
  const kindDiff = (order[a.kind] ?? 99) - (order[b.kind] ?? 99);
  if (kindDiff) return kindDiff;
  return naturalCode(a.code || String(a.id), b.code || String(b.id));
}

export function distance(a, b) {
  return Math.hypot((b.x || 0) - (a.x || 0), (b.y || 0) - (a.y || 0));
}

export function formatLength(length) {
  if (!Number.isFinite(length)) {
    return "";
  }
  if (length >= 1000) {
    return `${(length / 1000).toFixed(2)} km`;
  }
  return `${Math.round(length)} m`;
}


const ALL_BRANCH_LETTERS = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";

function allBranchOrdinalMap(eventModel, course) {
  const result = new Map();
  if (!course) return result;
  const branchCodes = branchCodeMapForCourse(eventModel, course);
  const maxSteps = Math.max(1000, (eventModel.courseControls?.length || 0) * 50);
  let steps = 0;

  function formatOrdinal(ordinal, suffix) {
    const text = String(ordinal || "");
    return suffix ? `${text}-${suffix}` : text;
  }

  function hiddenBranchMarker(ownerCourseControl, branchCourseControl) {
    if (!ownerCourseControl || !branchCourseControl) return false;
    return Number(branchCourseControl.id) === Number(ownerCourseControl.id)
      || Number(branchCourseControl.control) === Number(ownerCourseControl.control);
  }

  function branchStart(ownerCourseControl, branchCourseControl) {
    if (!branchCourseControl) return null;
    if (hiddenBranchMarker(ownerCourseControl, branchCourseControl)) {
      return Number(branchCourseControl.nextCourseControl) || null;
    }
    return Number(branchCourseControl.id) || null;
  }

  function visit(startId, stopId, ordinal, suffix, pathKey = "") {
    let currentId = Number(startId) || 0;
    let currentOrdinal = Number(ordinal) || 1;
    const stop = Number(stopId) || 0;
    const localSeen = new Set();

    while (currentId && currentId !== stop && steps++ < maxSteps) {
      const key = `${pathKey}:${suffix}:${currentId}:${stop}`;
      if (localSeen.has(key)) break;
      localSeen.add(key);

      const courseControl = getCourseControl(eventModel, currentId);
      const control = getControl(eventModel, courseControl?.control);
      if (!courseControl || !control) break;

      if (control.kind === "normal" && !isTeamFreeCourseControl(course, courseControl)) {
        result.set(Number(courseControl.id), formatOrdinal(currentOrdinal, suffix));
        currentOrdinal += 1;
      }

      if (courseControl.variation && courseControl.variationCourseControls?.length) {
        const branchBaseOrdinal = currentOrdinal;
        const branchEndOrdinals = [];
        for (const branchId of courseControl.variationCourseControls || []) {
          const branchCourseControl = getCourseControl(eventModel, branchId);
          if (!branchCourseControl) continue;
          const code = branchCodes.get(Number(branchCourseControl.id)) || "";
          const nextSuffix = [suffix, code].filter(Boolean).join("-");
          const branchEndOrdinal = visit(
            branchStart(courseControl, branchCourseControl),
            courseControl.variationEnd,
            branchBaseOrdinal,
            nextSuffix,
            `${pathKey}/${courseControl.id}:${branchCourseControl.id}`
          );
          branchEndOrdinals.push(branchEndOrdinal);
        }
        currentOrdinal = Math.max(branchBaseOrdinal, ...branchEndOrdinals);
        currentId = Number(courseControl.variation === "loop" ? courseControl.nextCourseControl : courseControl.variationEnd) || 0;
      }
      else {
        currentId = Number(courseControl.nextCourseControl) || 0;
      }
    }
    return currentOrdinal;
  }

  visit(course.firstCourseControl, null, course.firstControlOrdinal || 1, "", "root");
  return result;
}

function branchCodeMapForCourse(eventModel, course) {
  const result = new Map();
  let next = 0;
  const seen = new Set();
  const maxSteps = Math.max(1000, (eventModel.courseControls?.length || 0) * 50);
  let steps = 0;

  function visit(startId, stopId = null) {
    let currentId = Number(startId) || 0;
    const stop = Number(stopId) || 0;
    while (currentId && currentId !== stop && steps++ < maxSteps) {
      if (seen.has(currentId)) break;
      seen.add(currentId);
      const courseControl = getCourseControl(eventModel, currentId);
      if (!courseControl) break;
      if (courseControl.variation && courseControl.variationCourseControls?.length) {
        for (const branchId of courseControl.variationCourseControls || []) {
          const id = Number(branchId) || 0;
          if (id && !result.has(id)) {
            result.set(id, ALL_BRANCH_LETTERS[next] || `V${next + 1}`);
            next += 1;
          }
          const branchCourseControl = getCourseControl(eventModel, id);
          if (branchCourseControl) {
            const branchStartId = Number(branchCourseControl.control) === Number(courseControl.control)
              ? Number(branchCourseControl.nextCourseControl) || null
              : Number(branchCourseControl.id) || null;
            visit(branchStartId, courseControl.variationEnd);
          }
        }
        currentId = Number(courseControl.variation === "loop" ? courseControl.nextCourseControl : courseControl.variationEnd) || 0;
      }
      else {
        currentId = Number(courseControl.nextCourseControl) || 0;
      }
    }
  }

  visit(course?.firstCourseControl);
  return result;
}


export function teamCourseControlRole(course, courseControl) {
  if (course?.kind !== "team" || !courseControl) return "mandatory";
  return courseControl.teamRole === "free" ? "free" : "mandatory";
}

export function isTeamFreeCourseControl(course, courseControl) {
  return teamCourseControlRole(course, courseControl) === "free";
}

export function isTeamMandatoryCourseControl(course, courseControl) {
  return teamCourseControlRole(course, courseControl) !== "free";
}

function labelForControl(course, courseControl, control, ordinal) {
  if (control.kind !== "normal") {
    return controlKindLabel(control.kind);
  }
  const code = control.code || "";
  const teamFree = isTeamFreeCourseControl(course, courseControl);
  if (teamFree) {
    return code;
  }
  const score = course.kind === "score"
    ? String(Math.max(0, Number(courseControl?.points) || 0))
    : (courseControl?.points ? String(courseControl.points) : "");
  const labelKind = course.labelKind;
  switch (labelKind) {
    case "code": return code;
    case "sequence-and-code": return ordinal ? `${ordinal}-${code}` : code;
    case "sequence-and-code-slash": return ordinal ? `${ordinal}/${code}` : code;
    case "sequence-and-score": return score ? `${ordinal}(${score})` : String(ordinal);
    case "code-and-score-brackets": return score ? `${code}[${score}]` : code;
    case "code-and-score-dash": return score ? `${code}-${score}` : code;
    case "code-and-score":
    case "code-and-score-parens": return score ? `${code}(${score})` : code;
    case "score": return score;
    default: return String(ordinal);
  }
}

export function naturalCode(a, b) {
  const an = Number(a);
  const bn = Number(b);
  if (Number.isFinite(an) && Number.isFinite(bn) && an !== bn) {
    return an - bn;
  }
  return String(a).localeCompare(String(b), undefined, { numeric: true });
}
